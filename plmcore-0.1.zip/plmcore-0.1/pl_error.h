/* pl_error.h */

void pl_error(int);